import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class hp extends JPanel
{
    JButton b1,b2,b3;
    JLabel l;
hp()
{
 setLayout(null);
 setVisible(true);
b1=new JButton("click");
b1.setBounds(130,400,150,40);
add(b1);
}
}